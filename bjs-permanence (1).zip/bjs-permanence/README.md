# Permanence local BJS Droit

Planning des présences au local, ouverture / fermeture et détenteur de la clé.

## Mettre en ligne sur GitHub Pages
1. Crée un dépôt GitHub et dépose `index.html` et `banner.jpg` à la racine.
2. Settings > Pages > Source : branche `main`, dossier `/ (root)` > Save.
3. Le site est disponible après 1 à 2 minutes sur `https://TON-PSEUDO.github.io/NOM-DU-DEPOT/`.

## Utilisation
- Clique sur ton prénom, puis sur un jour : choisis Matin et/ou Après-midi.
- Dans un jour : Local ouvert / fermé, horaires, qui a la clé.
- Le planning est enregistré dans le navigateur de l'appareil. Utilise Exporter / Importer pour le partager.
